//---------------------------------------------------------------------------

#ifndef toolsH
#define toolsH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
//---------------------------------------------------------------------------
class Tftools : public TForm
{
__published:	// IDE-managed Components
private:	// User declarations
public:		// User declarations
	__fastcall Tftools(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE Tftools *ftools;
//---------------------------------------------------------------------------
#endif

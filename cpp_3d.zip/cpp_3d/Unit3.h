//---------------------------------------------------------------------------

#ifndef Unit3H
#define Unit3H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "CSPIN.h"
//---------------------------------------------------------------------------
class Tfproperties : public TForm
{
__published:	// IDE-managed Components
	TCSpinEdit *CSpinEdit1;
	TCSpinEdit *CSpinEdit2;
	TCSpinEdit *CSpinEdit3;
	TCSpinEdit *CSpinEdit4;
	TCSpinEdit *CSpinEdit5;
private:	// User declarations
public:		// User declarations
	__fastcall Tfproperties(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE Tfproperties *fproperties;
//---------------------------------------------------------------------------
#endif

//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit3.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "CSPIN"
#pragma resource "*.dfm"
Tfproperties *fproperties;
//---------------------------------------------------------------------------
__fastcall Tfproperties::Tfproperties(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
